# File: map_plot.py
# Author: Gift Christian
# Date: November 17, 2025
# Course: CS 1 - Introduction to Programming and Computation-02 By Professor Balkcom
# Description: This file contains the code to plot the graph on a map using cs1lib.

# Import necessary functions from cs1lib and the create_vertex_dictionary function
from cs1lib import start_graphics, load_image, draw_image, clear
from load_graph import create_vertex_dictionary

# Load the graph from the specified file
graph = create_vertex_dictionary("dartmouth_graph.txt")


def main():
    clear()
    img = load_image("dartmouth_map.png")       # Load the background map image
    draw_image(img, 0, 0)                       # Draw the map image at the origin (0,0)
    for vertex in graph:                        # Iterate through all vertices in the graph
        graph[vertex].draw_vertex(0, 0, 1)      # Draw each vertex in blue
        graph[vertex].draw_all_edges(0, 0, 1)   # Draw all edges in blue

start_graphics(main, width=1012, height=811)    # Start the graphics window with specified dimensions