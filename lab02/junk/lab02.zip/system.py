# File: system.py
# Author: Gift Christian
# Date: October 31, 2025
# Course: CS 1 - Introduction to Programming and Computation-02 By Professor Balkcom
# Description: A class representing a system of celestial bodies.

class System:
    def __init__(self, bodies):         # bodies is a list of Body objects
        self.bodies = bodies

    def draw(self, width, height, ppm):                             # ppm is pixels per meter
        for i in range(len(self.bodies)):                           # Draw each body
            self.bodies[i].draw(width, height, ppm)                 # Draw the i-th body from the list

    def update(self, ttimestep):
        for i in range(len(self.bodies)):
            self.bodies[i].update_postion(ttimestep)                # Update position of each body, a method in the Body class
            self.bodies[i].update_velocity(0.005, 0, ttimestep)     # Update velocity with accelerations (ax, ay) of each body, a method in the Body class

    def __str__(self):                                              # String representation of the System object
        body_strings = []
        for body in self.bodies:
            body_strings.append(str(body))
        return "System with bodies: " + str(body_strings)